export const MIN_SCREEN_WIDTH_SAFE_FOR_FRAME = 890

export const isInIframe = () => {
  try {
    return window.self !== window.top
  } catch (e) {
    return true
  }
}
