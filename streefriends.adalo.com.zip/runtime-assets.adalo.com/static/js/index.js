// Configure regeneratorRuntime first, so we don't error out
import './runtimeConfig'
import './rn-compatibility'
import 'core-js/stable'
import 'pwacompat'

import React from 'react'
import { createRoot } from 'react-dom/client'
import { asyncWithLDProvider } from 'launchdarkly-react-client-sdk'

import App from './components/App'

async function main() {
  const LaunchDarklyProvider = await asyncWithLDProvider({
    clientSideID: process.env.REACT_APP_LAUNCH_DARKLY_CLIENT_ID,
    reactOptions: {
      useCamelCaseFlagKeys: false,
    },
    user: {
      key: 'pre-init-fixed-key',
    },
  })

  const container = document.getElementById('root')
  const root = createRoot(container)

  root.render(
    <LaunchDarklyProvider>
      <App />
    </LaunchDarklyProvider>
  )
}

main()
