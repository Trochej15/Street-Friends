import regeneratorRuntime from 'regenerator-runtime'

window.regeneratorRuntime = regeneratorRuntime
