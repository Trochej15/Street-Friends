import Runner from '@protonapp/proton-runner'
import { withLDConsumer } from 'launchdarkly-react-client-sdk'

export default withLDConsumer()(Runner)
